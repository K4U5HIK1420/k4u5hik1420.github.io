import { motion } from "framer-motion";
import { Code2, Palette, Zap } from "lucide-react";

const cards = [
  {
    icon: Code2,
    title: "Clean Code",
    description: "Writing maintainable, scalable code with modern best practices and design patterns.",
  },
  {
    icon: Palette,
    title: "UI/UX Focus",
    description: "Crafting pixel-perfect interfaces that balance aesthetics with usability.",
  },
  {
    icon: Zap,
    title: "Performance",
    description: "Optimizing for speed, accessibility, and seamless user experiences.",
  },
];

const AboutSection = () => {
  return (
    <section id="about" className="py-24 lg:py-32">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-display mb-6">
            About <span className="text-accent">Me</span>
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            I'm a passionate full-stack developer with 5+ years of experience building
            production-grade applications. I specialize in React, Node.js, and cloud
            architectures — always pushing for cleaner code and better user experiences.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {cards.map((card, i) => (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: i * 0.15 }}
              className="glass rounded-2xl p-8 hover:shadow-xl transition-shadow duration-300 group"
            >
              <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-5 group-hover:bg-accent/20 transition-colors">
                <card.icon className="text-accent" size={24} />
              </div>
              <h3 className="font-display font-semibold text-lg mb-3">{card.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{card.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
