import { motion } from "framer-motion";

const timeline = [
  {
    year: "2023 – Present",
    title: "Senior Full-Stack Developer",
    org: "TechCorp Inc.",
    description: "Leading development of customer-facing products, mentoring junior developers, and architecting scalable microservices.",
    type: "work" as const,
  },
  {
    year: "2021 – 2023",
    title: "Full-Stack Developer",
    org: "StartupXYZ",
    description: "Built core platform features from scratch, implemented CI/CD pipelines, and improved performance by 40%.",
    type: "work" as const,
  },
  {
    year: "2020",
    title: "AWS Solutions Architect",
    org: "Amazon Web Services",
    description: "Certified cloud architect with expertise in designing distributed systems.",
    type: "cert" as const,
  },
  {
    year: "2017 – 2021",
    title: "B.S. Computer Science",
    org: "University of Technology",
    description: "Graduated with honors. Focused on algorithms, systems design, and human-computer interaction.",
    type: "edu" as const,
  },
];

const typeColors: Record<string, string> = {
  work: "bg-accent",
  cert: "bg-cta",
  edu: "bg-primary",
};

const ExperienceSection = () => {
  return (
    <section id="experience" className="py-24 lg:py-32 bg-muted/30">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-display mb-4">
            Experience & <span className="text-accent">Education</span>
          </h2>
        </motion.div>

        <div className="max-w-3xl mx-auto relative">
          {/* Vertical line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-border md:-translate-x-px" />

          {timeline.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className={`relative flex items-start gap-6 mb-12 md:mb-16 ${
                i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
              }`}
            >
              {/* Dot */}
              <div className="absolute left-4 md:left-1/2 -translate-x-1/2 top-2">
                <div className={`w-3 h-3 rounded-full ${typeColors[item.type]} ring-4 ring-background`} />
              </div>

              {/* Content */}
              <div className={`ml-12 md:ml-0 md:w-1/2 ${i % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"}`}>
                <span className="text-xs font-medium text-accent">{item.year}</span>
                <h3 className="font-display font-semibold text-lg mt-1">{item.title}</h3>
                <p className="text-sm text-muted-foreground font-medium">{item.org}</p>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
