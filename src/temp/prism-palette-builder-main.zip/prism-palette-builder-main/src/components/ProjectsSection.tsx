import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ExternalLink, Github } from "lucide-react";

const filters = ["All", "Frontend", "Full-Stack", "Open Source"];

const projects = [
  {
    title: "E-Commerce Platform",
    description: "A scalable e-commerce app with real-time inventory, payments, and admin dashboard.",
    tags: ["Full-Stack"],
    tech: ["Next.js", "Stripe", "PostgreSQL", "TailwindCSS"],
    color: "from-accent/20 to-cta/20",
  },
  {
    title: "AI Chat Interface",
    description: "Conversational AI dashboard with streaming responses and markdown rendering.",
    tags: ["Frontend"],
    tech: ["React", "TypeScript", "Framer Motion", "OpenAI"],
    color: "from-cta/20 to-primary/10",
  },
  {
    title: "DevTools CLI",
    description: "Open-source CLI toolkit for scaffolding and managing microservices.",
    tags: ["Open Source"],
    tech: ["Go", "Cobra", "Docker", "GitHub Actions"],
    color: "from-accent/30 to-accent/10",
  },
  {
    title: "Analytics Dashboard",
    description: "Real-time analytics with interactive charts, filters, and data export.",
    tags: ["Full-Stack"],
    tech: ["React", "D3.js", "Node.js", "MongoDB"],
    color: "from-primary/10 to-accent/20",
  },
  {
    title: "Design System",
    description: "Component library with 50+ accessible, themeable UI components.",
    tags: ["Open Source", "Frontend"],
    tech: ["React", "Storybook", "TailwindCSS", "Radix"],
    color: "from-cta/15 to-accent/15",
  },
  {
    title: "Task Manager",
    description: "Kanban-style project management app with real-time collaboration.",
    tags: ["Full-Stack"],
    tech: ["React", "Supabase", "TailwindCSS", "DnD Kit"],
    color: "from-accent/20 to-primary/10",
  },
];

const ProjectsSection = () => {
  const [active, setActive] = useState("All");

  const filtered = active === "All" ? projects : projects.filter((p) => p.tags.includes(active));

  return (
    <section id="projects" className="py-24 lg:py-32">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-display mb-4">
            Featured <span className="text-accent">Projects</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-10">
            A selection of projects I've built and contributed to.
          </p>

          <div className="flex flex-wrap justify-center gap-3">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setActive(f)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  active === f
                    ? "bg-accent text-accent-foreground shadow-lg shadow-accent/25"
                    : "glass text-muted-foreground hover:text-foreground"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filtered.map((project, i) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.1 }}
                className="glass rounded-2xl overflow-hidden group hover:shadow-xl transition-shadow duration-300"
              >
                <div className={`h-48 bg-gradient-to-br ${project.color} flex items-center justify-center`}>
                  <span className="font-display font-bold text-2xl text-foreground/30 group-hover:text-foreground/50 transition-colors">
                    {project.title.charAt(0)}
                  </span>
                </div>
                <div className="p-6">
                  <h3 className="font-display font-semibold text-lg mb-2">{project.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4 leading-relaxed">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-5">
                    {project.tech.map((t) => (
                      <span key={t} className="text-xs px-2.5 py-1 rounded-full bg-muted text-muted-foreground">
                        {t}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <a
                      href="#"
                      className="flex items-center gap-1.5 text-sm text-accent hover:text-accent/80 transition-colors font-medium"
                    >
                      <ExternalLink size={14} /> Live Demo
                    </a>
                    <a
                      href="#"
                      className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors font-medium"
                    >
                      <Github size={14} /> Source
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
};

export default ProjectsSection;
